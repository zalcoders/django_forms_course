from django.contrib import admin
from newsletter.models import Interest, Subscription


admin.site.register(Interest)
admin.site.register(Subscription)
